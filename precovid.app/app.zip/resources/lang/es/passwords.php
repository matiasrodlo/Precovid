<?php

    return [
        'reset' => '¡Tu contraseña ha sido restablecida!',
        'sent' => 'Hemos enviado un enlace de restablecimiento de contraseña a su correo electrónico',
        'throttled' => 'Por favor, espere antes de volver a intentar.',
        'token' => 'El código de restablecimiento de contraseña no es válido.',
        'user' => 'No podemos encontrar un usuario con esa dirección de correo electrónico.',
    ];
