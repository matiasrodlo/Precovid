

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row">
        <div class="col-lg-5 offset-lg-2 mb-5">
            <div class="card bg-primary text-white">
                <div class="card-header"><strong><?php echo e(__('app.titles.resultado')); ?></strong></div>

                <div class="card-body">
                    <h5 class="card-title"><?php echo e(__('app.resultados.title')); ?></h5>
                    <p class="card-text"><?php echo e(__('app.resultados.negativo')); ?></p>
                    <p class="card-text"><?php echo e(__('app.resultados.common')); ?></p>
                    <p class="card-text mb-0">
                        <a href="<?php echo e(url('/recomendaciones/negativo')); ?>" class="btn btn-light w-100"><?php echo e(__('app.buttons.recomendaciones')); ?></a>
                    </p>
                </div>
            </div>
        </div>

        <div class="col-lg-3">
            <div class="card bg-light">
                <div class="card-header"><strong><?php echo e(__('app.titles.share_whatsapp')); ?></strong></div>

                <div class="card-body">
                    <p class="card-text"><?php echo e(__('app.resultados.comparte')); ?></p>
                    <p class="card-text mb-0">
                        <a href="https://wa.me/?text=<?php echo e(__('app.contents.share_whatsapp')); ?>" class="btn btn-primary w-100" target="_blank"><?php echo e(__('app.buttons.compartir')); ?></a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.precovid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/meyzjcmc/precovid.cl/precovid.app/resources/views/evaluacion/negativo.blade.php ENDPATH**/ ?>