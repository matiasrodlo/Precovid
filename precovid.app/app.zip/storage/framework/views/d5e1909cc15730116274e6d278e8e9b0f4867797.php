<?php echo e($slot); ?>

<?php /**PATH /home/meyzjcmc/precovid.cl/precovid.app/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>