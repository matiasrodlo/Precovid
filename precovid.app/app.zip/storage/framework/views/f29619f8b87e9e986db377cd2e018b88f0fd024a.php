<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row">
        <div class="col-lg-8 offset-lg-2">
            <div class="card">
                <div class="card-header">
                    <strong><?php echo e(__('app.titles.verificar_cuenta')); ?></strong>
                </div>

                <div class="card-body">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('app.verification.email_sent')); ?>

                        </div>
                    <?php endif; ?>

                    <p class="card-text"><?php echo e(__('app.verification.before')); ?></p>
                    <p class="card-text"><?php echo e(__('app.verification.not_received')); ?>, 
                        <form action="<?php echo e(route('verification.resend')); ?>" method="post" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('app.verification.another')); ?></button>.
                        </form>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.precovid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/meyzjcmc/precovid.cl/precovid.app/resources/views/auth/verify.blade.php ENDPATH**/ ?>